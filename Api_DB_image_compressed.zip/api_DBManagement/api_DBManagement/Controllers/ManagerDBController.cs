﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using api_DBManagement.Context;
using api_DBManagement.Models;

namespace api_DBManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerDBController : ControllerBase
    {
        private readonly ManagerDBContext _context;

        public ManagerDBController(ManagerDBContext context)
        {
            _context = context;
        }

        // GET: api/ManagerDB
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ManagerDB>>> GetManager_DB()
        {
            // Error controller
            try
            {
                return await _context.ManagerDBs.ToListAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/ManagerDB/5
        // name fetch = GetManager_DB()
        [HttpGet("{id}", Name = "GetManagerDB")]
        public async Task<ActionResult<ManagerDB>> GetManagerDB(int id)
        {
            // Error controller
            try
            {
                // Using FindAsync from Linq library to get
                var ManagerDB = await _context.ManagerDBs.FindAsync(id);

                if (ManagerDB == null)
                {
                    return NotFound();
                }
                return ManagerDB;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: api/ManagerDB/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}", Name = "PutManagerDB")]
        public async Task<IActionResult> PutManagerDB(int id, ManagerDB ManagerDB)
        {
            if (id != ManagerDB.Id)
            {
                return BadRequest();
            }
            // update item
            _context.Entry(ManagerDB).State = EntityState.Modified;

            // Error controller
            try
            {

                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Manager_DBExists(id))
                {
                    return NotFound();
                }
                else
                {
                    return BadRequest();
                }
            }
            return NoContent();
        }

        // POST: api/ManagerDB
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost(Name = "PostManagerDB")]
        public async Task<ActionResult<ManagerDB>> PostManagerDB(ManagerDB ManagerDB)
        {
            // Error controller
            try
            {
                _context.ManagerDBs.Add(ManagerDB);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetManagerDB", new { id = ManagerDB.Id }, ManagerDB);
            }
            catch (Exception ex)
            {

                return BadRequest(ex);
            }
        }

        // DELETE: api/ManagerDB/5
        [HttpDelete("{id}", Name = "DeleteManagerDB")]
        public async Task<IActionResult> DeleteManager_DB(int id)
        {
            // Error controller
            try
            {
                var ManagerDB = await _context.ManagerDBs.FindAsync(id);
                if (ManagerDB == null)
                {
                    return NotFound();
                }
                _context.ManagerDBs.Remove(ManagerDB);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        private bool Manager_DBExists(int id)
        {
            return _context.ManagerDBs.Any(e => e.Id == id);
        }
    }
}
